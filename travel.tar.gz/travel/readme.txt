Task 3 and 4 are now done. The data files (.txt) in this folder are explained and illustrated throughout the pdf, so worry not with them.

the ga.py script is modifiable for how many cities you want to run for and the population numbers for both ga and hybrid.py are set to [10,100,1000].
 calling from terminal:

task 3: "python ga.py"
task 4: "python hybrid.py"

